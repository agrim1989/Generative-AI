from setuptools import find_packages, setup

setup(
    name = 'Generative AI Project',
    version= '0.0.0',
    author= 'Agrim Sharma',
    author_email= 'agrim89@gmail.com',
    packages= find_packages(),
    install_requires = []

)