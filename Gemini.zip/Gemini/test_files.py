# import streamlit as st
# from langchain.vectorstores import FAISS
# from langchain.embeddings import HuggingFaceEmbeddings
# from transformers import pipeline

# # Initialize summarization pipeline
# summarizer = pipeline("summarization")

# # Load the Faiss index with deserialization allowed
# def load_faiss_index(index_path):
#     embeddings = HuggingFaceEmbeddings(model_name='sentence-transformers/all-mpnet-base-v2',
#                                       model_kwargs={'device': 'cpu'})
#     vectorstore = FAISS.load_local(index_path, embeddings)
#     return vectorstore

# # Function to search the Faiss index
# def search_faiss_index(vectorstore, query, k=5):
#     # Generate embedding for the query using the embedding function from the vectorstore
#     query_embedding = vectorstore.embedding_function.embed_query(query)

#     # Search the index
#     results = vectorstore.similarity_search_by_vector(query_embedding, k=k)
#     return results

# # Function to summarize results
# def summarize_results(results):
#     combined_text = "\n\n".join([result.page_content for result in results])
#     summary = summarizer(combined_text, max_length=50, min_length=10, do_sample=False)
#     return summary[0]['summary_text']

# # Streamlit UI
# st.title("PDF Chatbot")

# # Load the Faiss index
# index_path = 'vectorstore/db_faiss'
# vectorstore = load_faiss_index(index_path)

# # User input for query
# query = st.text_input("Ask a question about the PDF:")

# if query:
#     # Search the Faiss index
#     results = search_faiss_index(vectorstore, query)

#     # Summarize and display results
#     summary = summarize_results(results)
#     st.write("Summary of Search Results:")
#     st.write(summary)

import streamlit as st
from langchain.vectorstores import FAISS
from langchain.embeddings import HuggingFaceEmbeddings
from transformers import pipeline

# Initialize summarization pipeline
summarizer = pipeline("summarization", model="facebook/bart-large-cnn")

# Load the FAISS index with deserialization allowed
@st.cache_resource
def load_faiss_index(index_path):
    embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-mpnet-base-v2",
                                       model_kwargs={"device": "cpu"})
    return FAISS.load_local(index_path, embeddings)

vectorstore = load_faiss_index("vectorstore/db_faiss")

# Function to search FAISS index
def search_faiss_index(vectorstore, query, k=5):
    query_embedding = vectorstore.embedding_function.embed_query(query)
    results = vectorstore.similarity_search_by_vector(query_embedding, k=k)
    return results

# Function to summarize results
def summarize_results(results):
    combined_text = "\n\n".join([result.page_content for result in results])
    summary = summarizer(combined_text, max_length=75, min_length=20, do_sample=False)
    return summary[0]["summary_text"]

# Streamlit UI
st.title("📄 PDF Conversational Chatbot")

# Initialize chat history
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

# Display chat history
for message in st.session_state.chat_history:
    with st.chat_message(message["role"]):
        st.write(message["content"])

# User input for conversation
user_query = st.chat_input("Ask me anything about the PDF...")

if user_query:
    # Display user message
    st.session_state.chat_history.append({"role": "user", "content": user_query})
    with st.chat_message("user"):
        st.write(user_query)

    # Retrieve relevant context from FAISS index
    search_results = search_faiss_index(vectorstore, user_query)

    # Summarize response
    bot_response = summarize_results(search_results)

    # Display chatbot response
    with st.chat_message("assistant"):
        st.write(bot_response)

    # Save response to chat history
    st.session_state.chat_history.append({"role": "assistant", "content": bot_response})
